Título: Rayuela, Autor: Julio Cortázar, ISBN: 978-8437604947
Título: La casa de los espíritus, Autor: Isabel Allende, ISBN: 978-1400034941
Título: La ciudad y los perros, Autor: Mario Vargas Llosa, ISBN: 978-8490626773
Título: Como agua para chocolate, Autor: Laura Esquivel, ISBN: 978-0385420174