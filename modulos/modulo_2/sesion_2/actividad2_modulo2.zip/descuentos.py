#Conocimientos básicos de Python
import zipfile
# Crear variables
precio_producto = 1200      # Precio del producto
cantidad = 3                # Cantidad comprada
descuento = 50              # Descuento en porcentaje

# Calcular el precio total sin descuento
total_sin_descuento = precio_producto * cantidad

# Calcular el monto de descuento
monto_descuento = total_sin_descuento * (descuento / 100)

# Calcular el precio total con descuento
total_con_descuento = total_sin_descuento - monto_descuento

# Imprimir los resultados
print("Total sin descuento: $", total_sin_descuento)
print("Monto de descuento: $", monto_descuento)
print("Total con descuento: $", total_con_descuento)

# Crear un archivo ZIP y añadir archivos a él
with zipfile.ZipFile('actividad2_modulo2.zip', 'w') as zipf:
    zipf.write('descuentos.py')  # Agrega archivo1.txt al ZIP